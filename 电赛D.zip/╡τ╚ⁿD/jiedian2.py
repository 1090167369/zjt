from flask import Flask
from flask_sockets import Sockets
import numpy as np
import cv2
from imutils.video import VideoStream
import imutils
import time
from scipy.fftpack import fft,ifft
import math
import socket
app = Flask(__name__)
sockets = Sockets(app)
cap = cv2.VideoCapture(0)

frameWidth = 960
frameHeight = 720
cap.set(3, frameWidth)          #参数3：设置视频框宽度
cap.set(4, frameHeight)         #参数4：设置视频框高
cap.set(10, 300)                #参数10：对应亮度
myColors = [[-10, 88, 100, 10, 255, 255]]  #HSV：前3个lower 后三个upper
s=8.9
myColorValues = [[126, 0, 0]]           #BGR红壶
myPoints = []  ##[x, y, colorId]
x_bi=[]
zonghe1 = 0
zonghe2 = 0
flag = 0
jieshou=1
@sockets.route('/send-frame')
def send_frame(ws):
    global zonghe1
    global zonghe2
    global flag
    start1 = cv2.getTickCount()
    sum_s=''
    y=[]
    while not ws.closed:
        imgResult = 0
        message = ws.receive()
        if message == "":
            continue
        elif message == "update":
            # Capture frame-by-frame
            
            start2 = cv2.getTickCount()
            ret, img = cap.read()
            if img is None:
                pass
            else:    
                imgResult = img.copy()      #备份原图片
                end1 = cv2.getTickCount()
                time1 = (end1 - start1)/cv2.getTickFrequency()
                zonghe1 = time1+zonghe1
                if(zonghe1>=1):
                    newPoints,x,y = findColor(img, myColors, myColorValues,imgResult,1)               
                    
                    end2 = cv2.getTickCount()
                    time2 = (end2 - start2)/cv2.getTickFrequency()
                    zonghe2 = zonghe2 + time2
                    if(x == 1 and flag == 0):
                        l=FFT_f(x_bi,zonghe2)
                        y.sort()
                        changdu = y[119]-y[0]
                        s1='%.03f' % l
                        s2='%03d' % changdu
                        sum_s=str(s1)+'s'+str(s2)
                        fa(sum_s)
                        flag = 1
                    else:
                    #fa(mm)
                        pass
                else:
                    newPoints,x,y = findColor(img, myColors, myColorValues,imgResult,0)
            #cv2.imshow("Result", newPoints)
            #gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                ret, jpg = cv2.imencode('.jpg', newPoints)
                ws.send(jpg.tostring())
        else:
            continue

def findColor(img, myColors, myColorValues,imgResult,biaozhi):
    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)   #BGR变HSV
    count = 0
    newPoints = []
    for color in myColors:
        lower = np.array(color[0:3])   
        upper = np.array(color[3:6])         # 分别设置HSV颜色空间中，对应颜色的阈值
        mask = cv2.inRange(imgHSV, lower, upper)
        mask = cv2.erode(mask, None, iterations=1)  #腐蚀去毛刺（完善图片边角）
        mask = cv2.dilate(mask, None, iterations=8) #膨胀恢复图像（适当调整大小可以实现将图片中间的一些无用特征去掉)
        img_fanhui , x = getContours(mask,imgResult)
        #cv2.circle(imgResult, (x, y), 10, myColorValues[count], cv2.FILLED)
        if(len(x_bi)<120 and biaozhi == 1):
            print(x)
            x_bi.append(x)
            return img_fanhui,0,[0]
        elif(len(x_bi)==120 and biaozhi == 1):
            for i in range(0,119):
                if(x_bi[i]==0 and i!=0 and i!=119):
                    x_bi[i] = (x_bi[i-1]+x_bi[i+1])/2
                if(x_bi[i]==0 and i==0):
                    x_bi[0] = x_bi[1]
                if(x_bi[i]==0 and i==119):
                    x_bi[119] = x_bi[118]  
            return img_fanhui,1,x_bi
        else:
            return img_fanhui,0,[0]
        # cv2.imshow(str(color[0]), mask)

def FFT_f(xzhou,time):
    global s
    xzhou_qu = []
    Fs = 120/(time+s)
    a=0
    b=0
    x=len(xzhou)
    yy = fft(xzhou)
    yf1=abs(fft(xzhou))/x
    yf2=yf1[range(int(x/2))]
    for i in range(1,int(len(yf2)/2)):
        if(yf2[i]>a):
            a=yf2[i]
            b=i
        else:
            continue
    
    f= Fs*b/x
    T = 1/f
    l=((T*T)*9.8015)/(4.0*(math.pi*math.pi))
    print(time)
    print(l)
    print(Fs)
    print(b)
    return l

def getContours(img,imgResult):
    imagess,contours,hierarchy = cv2.findContours(img,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)   #得到轮廓点集
    x, y, w, h = 0, 0, 0, 0     #设置数据储存识别物体的位置
    biaozhi =0
    for cnt in contours:        #依次取出识别的物体轮廓点集
        area = cv2.contourArea(cnt) #计算轮廓像素面积（详细看资料不是真实面积）
        if area>0 : 
            peri = cv2.arcLength(cnt,True)                          #计算得到弧长，形状是闭合的（True）
            approx = cv2.approxPolyDP(cnt,0.03*peri,True)           #传入轮廓的点集
            x, y, w, h = cv2.boundingRect(approx)                   #x，y是矩阵左上点的坐标，w，h是矩阵的宽和高
            cv2.rectangle(imgResult, (x,y), (x+w,y+h), (0,0,255), 2)
            #print(int(w),int(h),int(x),int(y))  
            #print(int(x+w/2), int(y+h/2))
    return imgResult , int(x+w/2)

def fa(zifu):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('202.201.244.20', 10002))  #绑定ip和端口号（IP为发送数据的树莓派ip，端口号自己指定）
    s.listen(2)
    c, address = s.accept()      #等待别的树莓派接入
    while(True):
        msg = zifu
        
        c.send(msg.encode('utf-8'))   #编码
        print(msg)
        #if(msg == '1'):     
        break
    s.close()
    
    
def jie():
    global jieshou
    a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        a.connect(('202.201.244.100', 6666))   #链接刚刚绑定的ip和端口号
    except:
        return 1
    else:
        while(True):
            msg1 = a.recv(1) 
            msg1 =  msg1.decode('utf-8')   #解码
        #print('recv:', msg)
            if(msg1=='1'):
                print(11)
                jieshou = 0
                break   
            else:
                continue
        a.close()



@app.route('/')
def hello():
    return 'Hello World!'


if __name__ == "__main__":
    while(jieshou):
        jie()
    from gevent import pywsgi
    from geventwebsocket.handler import WebSocketHandler
    server = pywsgi.WSGIServer(
        ('0.0.0.0', 4242), app, handler_class=WebSocketHandler)
    server.serve_forever()



