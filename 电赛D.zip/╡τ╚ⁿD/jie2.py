import time
import socket
import numpy as np
import cv2
import RPi.GPIO as GPIO
import math
jishu1 = 1
jishu2 = 1 
GPIO.setmode(GPIO.BCM)
GPIO.setup(21,GPIO.OUT)
GPIO.setup(26,GPIO.IN,pull_up_down=GPIO.PUD_DOWN)
def fa():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    v = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('202.201.244.100', 6665))  #绑定ip和端口号（IP为发送数据的树莓派ip，端口号自己指定）
    v.bind(('202.201.244.100', 6666))  #绑定ip和端口号（IP为发送数据的树莓派ip，端口号自己指定）
    s.listen(5)
    v.listen(5)
    c, address = s.accept()      #等待别的树莓派接入
    c1, address1 = v.accept()      #等待别的树莓派接入
    #start_time = time.time()
    while(True):
        msg = '1'

        c.send(msg.encode('utf-8'))   #编码
        c1.send(msg.encode('utf-8'))   #编码
        #if(msg == '1'):
        #if(time.time() - start_time == 2):
        s.close()
        v.close()
        print(66)
        break
        
def jie1():
    global jishu1
    xb=0
    lb=0
    a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        a.connect(('202.201.244.200', 10001))#链接刚刚绑定的ip和端口号      
    except:
        return 0,0
    else:
        while(True):
            msg = a.recv(9)
            msg =  msg.decode('utf-8')   #解码
            if(len(msg)==9):
                lb=int(msg[0])+int(msg[2])*0.1+int(msg[3])*0.01+int(msg[4])*0.001
                xb=int(msg[6])*100+int(msg[7])*10+int(msg[8])
            else:
                continue
            print('recv:', msg) 
            if(lb>0 and xb>0):
                jishu1 =0
                break
        a.close()
    return(lb,xb)

def jie2():
    global jishu2
    xb1=0
    lb1=0
    a1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        a1.connect(('202.201.244.20', 10002))
    except:
        return 0,0
    else:
        while(True):
            msg1 = a1.recv(9)
            msg1 = msg1.decode('utf-8')   #解码
            if(len(msg1)==9):
                lb1=int(msg1[0])+int(msg1[2])*0.1+int(msg1[3])*0.01+int(msg1[4])*0.001
                xb1=int(msg1[6])*100+int(msg1[7])*10+int(msg1[8])
            else:
                continue
            print('recv1:', msg1)
            if(lb1>0 and xb1>0):
                jishu2 =0
                break
        a1.close()
    return(lb1,xb1)

while(True):
    if(GPIO.input(26)==GPIO.HIGH):    
        fa()
        while(jishu1):
            lb,xb=jie1()
        while(jishu2):
            lb1,xb1 = jie2()
        if(lb!=0 and xb!=0 and lb1!=0 and xb1!=0):
            jiaodu = math.atan((xb/xb1))*(180/math.pi)
            beijing=cv2.imread('1.jpg',cv2.IMREAD_COLOR)
            if(xb<=35 and xb1>=60):
                if(jiaodu<5):
                    cv2.putText(beijing,str(lb1-0.03),(200,100),cv2.FONT_HERSHEY_COMPLEX,2,(0,255,255),5)
                    cv2.putText(beijing,str(jiaodu),(200,300),cv2.FONT_HERSHEY_COMPLEX,2,(255,255,0),5)
                else:
                    jiaodu = jiaodu-4
                    cv2.putText(beijing,str(lb1-0.03),(200,100),cv2.FONT_HERSHEY_COMPLEX,2,(0,255,255),5)
                    cv2.putText(beijing,str(jiaodu),(200,300),cv2.FONT_HERSHEY_COMPLEX,2,(255,255,0),5)
            elif(xb>=60 and xb1<=35):
                if(jiaodu>85):
                    cv2.putText(beijing,str(lb-0.03),(200,100),cv2.FONT_HERSHEY_COMPLEX,2,(0,255,255),5)
                    cv2.putText(beijing,str(jiaodu),(200,300),cv2.FONT_HERSHEY_COMPLEX,2,(255,255,0),5)
                else:
                    jiaodu = jiaodu+4
                    cv2.putText(beijing,str(lb-0.03),(200,100),cv2.FONT_HERSHEY_COMPLEX,2,(0,255,255),5)
                    cv2.putText(beijing,str(jiaodu),(200,300),cv2.FONT_HERSHEY_COMPLEX,2,(255,255,0),5)
            else:
                cv2.putText(beijing,str(((lb+lb1)/2)-0.03),(200,100),cv2.FONT_HERSHEY_COMPLEX,2,(0,255,255),5)
                cv2.putText(beijing,str(jiaodu),(200,300),cv2.FONT_HERSHEY_COMPLEX,2,(255,255,0),5)
            cv2.imshow('color_image',beijing)
            print(lb)
            print(lb1)
            GPIO.output(21,GPIO.HIGH)
            time.sleep(2)
            GPIO.output(21,GPIO.LOW)
            cv2.waitKey(0)
            cv2.destroyAllqwindows()
            
        else:
            pass
    else:
        continue
        
        
        
        
        

